// This is an abstract class that will pass the daily work out plans down to the Day class

package application;

public abstract class Plan{
	
	// initialize fields
	private int dailySteps;
	private String dailyFocus;
	private Boolean restDay;

	
	// constructors
	public Plan() {}
	
	public Plan(int dailySteps, String dailyFocus, Boolean restDay) {
		this.dailySteps = 10000;
		this.dailyFocus = "Cardio";
		this.restDay = false;
	}
	
	// setters
	public void setDailySteps(int dailySteps) {
		this.dailySteps = dailySteps;
	}
	
	
	public void setFocusArms() {
		this.dailyFocus = "Arms";
	}
	
	public void setFocusLegs() {
		this.dailyFocus = "Legs";
	}
	
	
	public void setFocusRest() {
		this.dailyFocus = "Rest day";
	}
	
	public void setRestDay(Boolean restDay) {
		this.restDay = restDay;
	}
	
	// getters
	public int getDailySteps() {
		return this.dailySteps;
	}
	
	public String getDailyFocus() {
		return this.dailyFocus;
	}
	
	public Boolean getRestDay() {
		return this.restDay;
	}
}
