/* Ethan Deatrick
   SDEV200
   12/MAR/2023
   Semester Project - Weekly Exercise Plan Generator
   
   This application uses javaFX to create an interface that allows a user to create a
   weekly exercise plan. After the plan is created, it will be saved to a file, which the
   user can load to review their plan at any time.
   
 */

package application;
	
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;


public class Main extends Application {
	
	// create stage and scenes
	Stage window;
	Scene main, create, daily, plan, load;
		
	// create person object to hold user attributes
	public Person person = new Person();
	
	// create day objects to hold daily plans
	Day sun = new Day("Sunday");
	Day mon = new Day("Monday");
	Day tue = new Day("Tuesday");
	Day wed = new Day("Wednesday");
	Day thu = new Day("Thursday");
	Day fri = new Day("Friday");
	Day sat = new Day("Saturday");
	
	// load menu text field
	private TextField loadPlan = new TextField();
	
	// daily plan menu text fields
	private TextField sunSteps = new TextField();
	private TextField monSteps = new TextField();
	private TextField tueSteps = new TextField();
	private TextField wedSteps = new TextField();
	private TextField thuSteps = new TextField();
	private TextField friSteps = new TextField();
	private TextField satSteps = new TextField();
	
	// create menu text fields
	private TextField firstName = new TextField();
	private TextField lastName = new TextField();
	private TextField age = new TextField();
	private TextField weight = new TextField();
	private TextField goalDaySteps = new TextField();
	private TextField goalWeight = new TextField();
	
	
	
	@Override
	public void start(Stage primaryStage) {
		// set window to primary stage
		window = primaryStage;
		
		// Create Main Menu GUI using VBox
		VBox mainMenu = new VBox();
		// set vBox padding and spacing
		mainMenu.setSpacing(10);
		mainMenu.setPadding(new Insets(0, 10, 10, 20));
		
		// main label
		Label mainLabel = new Label("Weekly Exercise Plan Generator");
		mainLabel.setFont(new Font("Arial", 24));
		// button to create new plan
		Button createPlan = new Button("Create New Plan");
		createPlan.setOnAction(e -> create());
		// button to load plan
		Button loadPlan = new Button("Load Plan");
		loadPlan.setOnAction(e -> load());
		// button to exit program
		Button exit = new Button("Exit");
		exit.setOnAction(e -> window.close());	
		
		// set node properties
		mainMenu.setAlignment(Pos.CENTER);	
		createPlan.setMaxWidth(130);
		loadPlan.setMaxWidth(130);
		exit.setMaxWidth(130);
		mainMenu.getChildren().addAll(mainLabel, createPlan, loadPlan, exit);
		main = new Scene(mainMenu, 420, 300);
		
			
		// create start menu
		primaryStage.setTitle("Weekly Exercise Plan");
		primaryStage.setScene(main);
		primaryStage.setResizable(false);
		primaryStage.show();
		
		
	}
	
	
	private void create() {
		
		// create new scene to begin creating new plan
		GridPane createMenu = new GridPane();
		createMenu.setHgap(20);
		createMenu.setVgap(5);
		createMenu.setPadding(new Insets(15,30,20,40));
		// create buttons
		Button goBack = new Button("Go Back");
		Button next = new Button("Next");
		Label mainLabel = new Label("Create Plan");
		mainLabel.setFont(new Font("Arial", 14));
		Label errorLabel = new Label("Please enter valid input");
		// Place label, text field, and button nodes
		createMenu.add(mainLabel, 1, 0);
		createMenu.add(new Label("First Name:"), 0, 1);
		createMenu.add(firstName, 2, 1);
		createMenu.add(new Label("Last Name:"), 0, 2);
		createMenu.add(lastName, 2, 2);
		createMenu.add(new Label("Age:"), 0, 3);
		createMenu.add(age, 2, 3);
		createMenu.add(new Label("Weight:"), 0, 4);
		createMenu.add(weight, 2, 4);
		createMenu.add(new Label("Goal Weight:"), 0, 5);
		createMenu.add(goalWeight, 2, 5);
		createMenu.add(new Label("Daily step goal:"), 0, 6);
		createMenu.add(goalDaySteps, 2, 6);
		createMenu.add(goBack, 0, 7);
		createMenu.add(next, 2, 7);
		GridPane.setHalignment(next, HPos.RIGHT);
		// create and set scene
		create = new Scene(createMenu, 420, 300);
		window.setScene(create);
		
		// when pressing 'go back' button, move back to main scene
		goBack.setOnAction(e -> window.setScene(main));
		
		// When pressing 'next' button, set values and move to next scene
		next.setOnAction(e -> {	
			
			try {
				person.setFirst(firstName.getText());
				person.setLast(lastName.getText());
				person.setAge(Integer.parseInt(age.getText()));
				person.setWeight(Double.parseDouble(weight.getText()));
				person.setGoalDaySteps(Integer.parseInt(goalDaySteps.getText()));
				person.setGoalWeight(Double.parseDouble(goalWeight.getText()));
				person.setGoalWeekSteps();
				dailyPlan();
			}
			catch (Exception x) {
				createMenu.add(errorLabel, 2, 0);
				mainLabel.setText("Error: ");
			}
		});		
		
	}
	
	private void dailyPlan () {
		
		// create new scene using grid pane
		GridPane dailyPlanMenu = new GridPane();
		dailyPlanMenu.setHgap(5);
		dailyPlanMenu.setVgap(5);
		dailyPlanMenu.setPadding(new Insets(15,20,15,15));
		
		// Creates toggle group for each day of week to determine radio button selection
		ToggleGroup sunTog = new ToggleGroup();
		ToggleGroup monTog = new ToggleGroup();
		ToggleGroup tueTog = new ToggleGroup();
		ToggleGroup wedTog = new ToggleGroup();
		ToggleGroup thuTog = new ToggleGroup();
		ToggleGroup friTog = new ToggleGroup();
		ToggleGroup satTog = new ToggleGroup();
		
		// create labels
		Label lab1 = new Label("Focus");
		Label lab2 = new Label("Steps");		
		
		dailyPlanMenu.add(lab1, 4, 0);
		dailyPlanMenu.add(lab2, 2, 0);
		
		// Creating radio buttons and text fields for focus and daily steps
		RadioButton sunRad1 = new RadioButton("Arms");
		RadioButton sunRad2 = new RadioButton("Legs");
		RadioButton sunRad3 = new RadioButton("Rest");
		sunRad1.setToggleGroup(sunTog);
		sunRad2.setToggleGroup(sunTog);
		sunRad3.setToggleGroup(sunTog);
		RadioButton monRad1 = new RadioButton("Arms");
		RadioButton monRad2 = new RadioButton("Legs");
		RadioButton monRad3 = new RadioButton("Rest");
		monRad1.setToggleGroup(monTog);
		monRad2.setToggleGroup(monTog);
		monRad3.setToggleGroup(monTog);
		RadioButton tueRad1 = new RadioButton("Arms");
		RadioButton tueRad2 = new RadioButton("Legs");
		RadioButton tueRad3 = new RadioButton("Rest");
		tueRad1.setToggleGroup(tueTog);
		tueRad2.setToggleGroup(tueTog);
		tueRad3.setToggleGroup(tueTog);
		RadioButton wedRad1 = new RadioButton("Arms");
		RadioButton wedRad2 = new RadioButton("Legs");
		RadioButton wedRad3 = new RadioButton("Rest");
		wedRad1.setToggleGroup(wedTog);
		wedRad2.setToggleGroup(wedTog);
		wedRad3.setToggleGroup(wedTog);
		RadioButton thuRad1 = new RadioButton("Arms");
		RadioButton thuRad2 = new RadioButton("Legs");
		RadioButton thuRad3 = new RadioButton("Rest");
		thuRad1.setToggleGroup(thuTog);
		thuRad2.setToggleGroup(thuTog);
		thuRad3.setToggleGroup(thuTog);
		RadioButton friRad1 = new RadioButton("Arms");
		RadioButton friRad2 = new RadioButton("Legs");
		RadioButton friRad3 = new RadioButton("Rest");
		friRad1.setToggleGroup(friTog);
		friRad2.setToggleGroup(friTog);
		friRad3.setToggleGroup(friTog);
		RadioButton satRad1 = new RadioButton("Arms");
		RadioButton satRad2 = new RadioButton("Legs");
		RadioButton satRad3 = new RadioButton("Rest");
		satRad1.setToggleGroup(satTog);
		satRad2.setToggleGroup(satTog);
		satRad3.setToggleGroup(satTog);
		
		// place labels, radio buttons, and text fields.
//		dailyPlanMenu.add(new Label("Steps"), 4, 0);
//		dailyPlanMenu.add(new Label("Focus"), 2, 0);
		dailyPlanMenu.add(new Label("Sunday: "), 0, 2);
		dailyPlanMenu.add(sunRad1, 1, 2);
		dailyPlanMenu.add(sunRad2, 2, 2);
		dailyPlanMenu.add(sunRad3, 3, 2);
		dailyPlanMenu.add(sunSteps, 4, 2);
		dailyPlanMenu.add(new Label("Monday: "), 0, 3);
		dailyPlanMenu.add(monRad1, 1, 3);
		dailyPlanMenu.add(monRad2, 2, 3);
		dailyPlanMenu.add(monRad3, 3, 3);
		dailyPlanMenu.add(monSteps, 4, 3);
		dailyPlanMenu.add(new Label("Tuesday: "), 0, 4);
		dailyPlanMenu.add(tueRad1, 1, 4);
		dailyPlanMenu.add(tueRad2, 2, 4);
		dailyPlanMenu.add(tueRad3, 3, 4);
		dailyPlanMenu.add(tueSteps, 4, 4);
		dailyPlanMenu.add(new Label("Wednesday: "), 0, 5);
		dailyPlanMenu.add(wedRad1, 1, 5);
		dailyPlanMenu.add(wedRad2, 2, 5);
		dailyPlanMenu.add(wedRad3, 3, 5);
		dailyPlanMenu.add(wedSteps, 4, 5);
		dailyPlanMenu.add(new Label("Thursday: "), 0, 6);
		dailyPlanMenu.add(thuRad1, 1, 6);
		dailyPlanMenu.add(thuRad2, 2, 6);
		dailyPlanMenu.add(thuRad3, 3, 6);
		dailyPlanMenu.add(thuSteps, 4, 6);
		dailyPlanMenu.add(new Label("Friday: "), 0, 7);
		dailyPlanMenu.add(friRad1, 1, 7);
		dailyPlanMenu.add(friRad2, 2, 7);
		dailyPlanMenu.add(friRad3, 3, 7);
		dailyPlanMenu.add(friSteps, 4, 7);
		dailyPlanMenu.add(new Label("Saturday: "), 0, 8);
		dailyPlanMenu.add(satRad1, 1, 8);
		dailyPlanMenu.add(satRad2, 2, 8);
		dailyPlanMenu.add(satRad3, 3, 8);
		dailyPlanMenu.add(satSteps, 4, 8);
		
		// 'go back' button takes user back to main menu
		Button goBack = new Button("Go Back");
		dailyPlanMenu.add(goBack, 0, 9);
		goBack.setOnAction(e -> window.setScene(main));
		
		// 'save and show plan' button stores information in day objects and moves to next scene
		Button next = new Button("Save and show plan");
		dailyPlanMenu.add(next, 4, 9);
		GridPane.setHalignment(next, HPos.RIGHT);
		next.setOnAction(e -> {
			// use if else statements to assign radio button selections. uses input validation
			try {
				if (sunRad1.isSelected()) {
					sun.setFocusArms();
				}else if (sunRad2.isSelected()) {
					sun.setFocusLegs();
				}else if (sunRad3.isSelected()) {
					sun.setFocusRest();	
				}
				sun.setDailySteps(Integer.parseInt(sunSteps.getText()));
				if (monRad1.isSelected()) {
					mon.setFocusArms();
				}else if (monRad2.isSelected()) {
					mon.setFocusLegs();
				}else if (monRad3.isSelected()) {
					mon.setFocusRest();	
				}
				mon.setDailySteps(Integer.parseInt(monSteps.getText()));
				if (tueRad1.isSelected()) {
					tue.setFocusArms();
				}else if (tueRad2.isSelected()) {
					tue.setFocusLegs();
				}else if (tueRad3.isSelected()) {
					tue.setFocusRest();	
				}
				tue.setDailySteps(Integer.parseInt(tueSteps.getText()));
				if (wedRad1.isSelected()) {
					wed.setFocusArms();
				}else if (wedRad2.isSelected()) {
					wed.setFocusLegs();
				}else if (wedRad3.isSelected()) {
					wed.setFocusRest();	
				}
				wed.setDailySteps(Integer.parseInt(wedSteps.getText()));
				if (thuRad1.isSelected()) {
					thu.setFocusArms();
				}else if (thuRad2.isSelected()) {
					thu.setFocusLegs();
				}else if (thuRad3.isSelected()) {
					thu.setFocusRest();	
				}
				thu.setDailySteps(Integer.parseInt(thuSteps.getText()));
				if (friRad1.isSelected()) {
					fri.setFocusArms();
				}else if (friRad2.isSelected()) {
					fri.setFocusLegs();
				}else if (friRad3.isSelected()) {
					fri.setFocusRest();	
				}
				fri.setDailySteps(Integer.parseInt(friSteps.getText()));
				if (satRad1.isSelected()) {
					sat.setFocusArms();
				}else if (satRad2.isSelected()) {
					sat.setFocusLegs();
				}else if (satRad3.isSelected()) {
					sat.setFocusRest();	
				}
				sat.setDailySteps(Integer.parseInt(satSteps.getText()));
				
				save();
				showPlan();
			}
			catch (Exception x) {
				lab1.setText("Must fill out completely");
				lab2.setText("Error: ");
			}
		});
		
		daily = new Scene(dailyPlanMenu, 420, 300);
		window.setScene(daily);		
	}
	
	private void showPlan () {
		// Create new scene to display finalized plan
		VBox showPlan = new VBox();
		// create nodes, set properties
		TextArea planArea = new TextArea();
		Button goBack = new Button("Go Back");
		showPlan.setAlignment(Pos.CENTER);
		planArea.setMaxWidth(200);
		planArea.setEditable(false);
		planArea.setPrefColumnCount(15);
	    planArea.setPrefHeight(200);
	    planArea.setPrefWidth(150);
	    // 'go back' button returns to main menu
		goBack.setOnAction(e -> window.setScene(main));
		showPlan.getChildren().addAll(planArea, goBack);
		//create and set scene
		plan = new Scene(showPlan, 420, 300);
		window.setScene(plan);
		
		// Buffered reader will read through saved file to display work out plan
		try {
				BufferedReader reader = new BufferedReader(new FileReader(person.getFirst() + ".txt"));
			
				String line;
				while((line = reader.readLine()) != null) {
				planArea.appendText(line + "\n");
			}
				
			reader.close();
			
		} catch (IOException x) {
			x.printStackTrace();
		}
	}
	
	private void save() {
		// save plan to text file using first name as file name
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(person.getFirst() + ".txt"));
			
			writer.write("Name: " + person.getName() + "\n");
			writer.write("Age: " + person.getAge() + "\n");
			writer.write("Weight: " + String.format("%.2f", person.getWeight()) + "\n");		
			writer.write("Goal Weight: " + String.format("%.2f", person.getGoalWeight()) + "\n");
			writer.write("Daily step goal: " + person.getGoalDaySteps() + "\n");
			writer.write("Weekly step goal: " + person.getGoalWeekSteps() + "\n");
			writer.write("\n");
			writer.write("Sunday focus: " + sun.getDailyFocus() + "\n");
			writer.write("Steps: " + sun.getDailySteps() + "\n");
			writer.write("Monday focus: " + mon.getDailyFocus() + "\n");
			writer.write("Steps: " + mon.getDailySteps() + "\n");
			writer.write("Tuesday focus: " + tue.getDailyFocus() + "\n");
			writer.write("Steps: " + tue.getDailySteps() + "\n");
			writer.write("Wednesday focus: " + wed.getDailyFocus() + "\n");
			writer.write("Steps: " + wed.getDailySteps() + "\n");
			writer.write("Thursday focus: " + thu.getDailyFocus() + "\n");
			writer.write("Steps: " + thu.getDailySteps() + "\n");
			writer.write("Friday focus: " + fri.getDailyFocus() + "\n");
			writer.write("Steps: " + fri.getDailySteps() + "\n");
			writer.write("Saturday focus: " + sat.getDailyFocus() + "\n");
			writer.write("Steps: " + sat.getDailySteps() + "\n");
			
			
			writer.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	private void load() {
		
		// create new scene to load plan from text file
		VBox loadMenu = new VBox();
		loadMenu.setSpacing(10);
		loadMenu.setPadding(new Insets(0, 10, 10, 20));
		loadMenu.setAlignment(Pos.CENTER);
		loadPlan.setAlignment(Pos.CENTER);
		loadPlan.setMaxWidth(130);
		// create buttons, labels, text area
		Label loadLabel = new Label("Enter first name to load plan");
		Button loadMyPlan = new Button("Load");
		Button goBack = new Button("Go Back");
		goBack.setOnAction(e -> window.setScene(main));
		TextArea area = new TextArea();
		area.setMaxWidth(200);
		area.setEditable(false);
		area.setPrefColumnCount(15);
	    area.setPrefHeight(200);
	    area.setPrefWidth(150);
	    loadMenu.getChildren().addAll(loadLabel, loadPlan, loadMyPlan, area, goBack);
		load = new Scene(loadMenu, 420, 300);
		window.setScene(load);
	    
		// Load button will use buffered reader to read lines from file to display in text box.
		loadMyPlan.setOnAction(e -> {
			try {
				BufferedReader reader = new BufferedReader(new FileReader(loadPlan.getText() + ".txt"));
				
				String line;
				while((line = reader.readLine()) != null) {
					area.appendText(line + "\n");
				}
					
				reader.close();
				
			} catch (IOException x) {
				x.printStackTrace();
			}
	    });
	    
		
		
	}
	
	// launch main method
	public static void main(String[] args) {
		launch(args);
	}
}
