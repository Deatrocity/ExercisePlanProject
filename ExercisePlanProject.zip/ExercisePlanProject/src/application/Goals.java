// This class will create an object that stores a various goals. Parent of 'Person' class.
package application;

public class Goals{
	
	private int goalDaySteps;
	private int goalWeekSteps;
	private double goalWeight;
	
	// constructors
	Goals() {}
	Goals(int goalDaySteps, double goalWeight){
		this.goalDaySteps = goalDaySteps;
		this.goalWeight = goalWeight;
	}
	
	// getters and setters
	public void setGoalDaySteps(int goalDaySteps) {
		this.goalDaySteps = goalDaySteps;
	}
	
	public int getGoalDaySteps() {
		return this.goalDaySteps;
	}
	
	public void setGoalWeekSteps() {
		this.goalWeekSteps = goalDaySteps * 7;
	}
	
	public int getGoalWeekSteps() {
		return this.goalWeekSteps;
	}
	
	public void setGoalWeight(double goalWeight) {
		this.goalWeight = goalWeight;
	}
	
	public double getGoalWeight() {
		return this.goalWeight;
	}
	
	
	
	
	

}
