// Creates a day object to represent day of the week. inherits from abstract Plan class.

package application;

public class Day extends Plan{
	private String dayName;
	
	Day() {}
	Day(String dayName){
		this.dayName = dayName;
	}
	
	public void setDay(String dayName) {
		this.dayName = dayName;
	}
	
	public String getDay() {
		return this.dayName;
	}

}
