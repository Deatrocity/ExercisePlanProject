// Creates a person object that stores a users information, inherits goal fields from 'Goals' parent.
package application;

public class Person extends Goals {
	
	// declare fields of Person object
	private String firstName;
	private String lastName;
	private int age;
	private double weight;
	
	// no arg constructor
	public Person () {}
		
	// constructor with variables
	public Person (String firstName, String lastName, int age, float weight) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.weight = weight;
	}
	
	// Setter Methods
	public void setFirst(String firstName) {
		this.firstName = firstName;
	}
	public void setLast(String lastName) {
		this.lastName = lastName;
	}
	public void setAge(int age) {
		this.age = age;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}
		
		
		
	// Getter methods
	public String getFirst() {
		return this.firstName;
	}
	public String getLast() {
		return this.lastName;
	}
	public String getName() {
		return (this.firstName + " " + this.lastName);
	}
	public int getAge() {
		return this.age;
	}
	public double getWeight() {
		return this.weight;
	}
	
	

}


